Arabidopsis thaliana

Program na vyhodnoceni zelene plochy.


Puvodni snimky musi byt ulozeny ve slozce 'images'.

Hlavnim souborem je Thaliana. 

Ostatni jsou funkce, na ktere se odvolava:
1) miska_thaliana.m
2) myfindpeaks.m
3) pozice_thaliana
4) vysledky_thaliana


Do slozky 'results' ulozi vysledky identifikaci misky, jamek a rostlin.
Obrazky ve slozce 'results' jsou v puvodnim rozliseni, cervene je identifikovana jamka a modre okraje kytky.

Zapise 'results.xlsx' s cislenymi vysledky.


